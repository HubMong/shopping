package service;

import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import mapper.AdminMapper;
import mapper.OrderMapper;
import model.Book;
import model.StatPoint;   // [ADDED] 통계 DTO 임포트

@Service
public class AdminService {

    @Autowired private AdminMapper adminMapper;
    @Autowired private OrderMapper orderMapper;
    @Autowired private ServletContext servletContext;

    public List<Book> getBookList() { return adminMapper.getBookList(); }

    public List<Book> searchBooks(String keyword) { return adminMapper.searchBooks(keyword); }

    public void save(Book book, MultipartFile file) { /* ... 기존 그대로 ... */ }

    public Book getBook(int id) { return adminMapper.getBook(id); }

    public void update(Book book, MultipartFile file) { /* ... 기존 그대로 ... */ }

    public void delete(int id) { adminMapper.delete(id); }

    // [ADDED] 인기 도서 Top-N (기간 필터)
    public List<StatPoint> getTopBookSales(String startDate, String endDate, int limit) {
        return orderMapper.selectTopBookSales(startDate, endDate, limit);
    }

}
