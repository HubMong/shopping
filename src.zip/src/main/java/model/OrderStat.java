package model;

public class OrderStat {
    private String label; // YYYY / YYYY-MM / YYYY-MM-DD
    private int count;

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }
}
